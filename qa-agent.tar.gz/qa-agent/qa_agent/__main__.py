"""Allow running as: python -m qa_agent run <url>"""
from qa_agent.cli import main
main()
