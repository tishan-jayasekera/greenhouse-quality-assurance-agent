"""Social Garden QA Checklist Agent — Automated landing page validation."""
__version__ = "0.1.0"
